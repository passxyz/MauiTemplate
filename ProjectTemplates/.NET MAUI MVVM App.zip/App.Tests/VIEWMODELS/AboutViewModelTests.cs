﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $ext_safeprojectname$.App.ViewModels;

namespace $safeprojectname$.ViewModels
{
    public class AboutViewModelTests
    {
        [Fact]
        public void SetTitleTest()
        {
            string AboutTitle = "AboutTest";
            AboutViewModel viewModel = new();
            viewModel.Title = AboutTitle;
            Assert.Equal(AboutTitle, viewModel.Title);
        }
    }
}
