﻿using Microsoft.Extensions.Logging;
using Microsoft.Maui.Controls.Core.UnitTests;
using NSubstitute;
using $ext_safeprojectname$.App.Models;
using $ext_safeprojectname$.App.Services;
using $ext_safeprojectname$.App.ViewModels;
using $ext_safeprojectname$.App.Views;

namespace $safeprojectname$.ViewModels
{
    public class NewItemViewModelTests : ShellTestBase
    {
        Microsoft.Maui.Controls.Application app;
        ILogger<NewItemViewModel> logger;
        readonly IDataStore<Item> dataStore;
        TestShell shell;

        public NewItemViewModelTests() 
        {
            using ILoggerFactory loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
            logger = loggerFactory.CreateLogger<NewItemViewModel>();
            dataStore = new MockDataStore();

            Routing.RegisterRoute(nameof(ItemDetailPage), typeof(ContentPage));
            Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
            shell = new TestShell();
            var aboutPage = new ShellItem { Route = "About" };
            var page = MakeSimpleShellSection("Maui", "content");
            aboutPage.Items.Add(page);
            shell.Items.Add(aboutPage);

            app = Substitute.For<Microsoft.Maui.Controls.Application>();
            app.MainPage = shell;
        }

        [Fact]
        public void CannotAddNewItem() 
        {
            NewItemViewModel vm = new(dataStore, logger);
            Assert.False(vm.SaveCommand.CanExecute(null));
        }

        [Fact]
        public void CanAddNewItem()
        {
            NewItemViewModel vm = new(dataStore, logger);
            vm.Name = "New item";
            vm.Description = "Can add new item";
            Assert.True(vm.SaveCommand.CanExecute(null));
        }

        [Fact]
        public async void CancelNewItem() 
        {
            NewItemViewModel vm = new(dataStore, logger);
            await shell.GoToAsync("//About/Maui/");
            vm.CancelCommand.Execute(null);
            Assert.Equal("//About/Maui/content", Shell.Current.CurrentState.Location.ToString());
        }

        [Fact]
        public async void SaveNewItem()
        {
            // Arrange
            await shell.GoToAsync("//About/Maui/");
            var items = await dataStore.GetItemsAsync(true);
            int Count1 = items.Count();
            NewItemViewModel vm = new(dataStore, logger);
            vm.Name = "New item";
            vm.Description = "Testing save command";
            // Act
            vm.SaveCommand.Execute(null);
            items = await dataStore.GetItemsAsync(true);
            int Count2 = items.Count();
            // Assert
            Assert.Equal(Count1+1, Count2);
        }

        [Fact]
        public void CreateNewItemViewModelSuccessTest()
        {
            // Arrange and Act
            NewItemViewModel vm = new(dataStore, logger);
            vm.Name = "New item";
            vm.Description = "This is a new item";
            // Assert
            Assert.Equal("New item", vm.Name);
            Assert.Equal("This is a new item", vm.Description);
        }

        [Fact]
        public void CreateNewItemViewModelFailureTest()
        {
            IDataStore<Item> dataStore = null;
            NewItemViewModel viewModel1;
            var ex = Assert.Throws<ArgumentNullException>(() => viewModel1 = new NewItemViewModel(dataStore, logger));
            Assert.Equal("Value cannot be null. (Parameter 'dataStore')", ex.Message);
        }
    }
}
