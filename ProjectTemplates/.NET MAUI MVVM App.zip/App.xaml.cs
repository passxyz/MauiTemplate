﻿using $safeprojectname$.Services;
using $safeprojectname$.Views;

namespace $safeprojectname$;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();
		MainPage = new AppShell();
	}
}
